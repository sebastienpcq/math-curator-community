# Math Curator Community 1.0

Extension Chrome Manifest V3 locale et gratuite. Version communautaire allégée de Math Curator V8 (moteur de filtrage de métadonnées conservé, laboratoire scientifique et dépendance Ollama retirés).

## Installer
1. Décompresser le ZIP. 2. Ouvrir `chrome://extensions/`. 3. Activer Mode développeur. 4. Charger l’extension non empaquetée, sélectionner le dossier `math-curator-community`. 5. Cliquer sur l'extension et activer le filtrage.

## Fonctionnement
- Filtre l’accueil, les résultats et les suggestions selon les titres et métadonnées accessibles sur la page.
- Modes exploration, équilibré, strict. Débutant/tous/intermédiaire/avancé. Domaines. Masquage Shorts. Favoris locaux. Restauration immédiate.
- Aucun accès réseau depuis l’extension, aucune clé API, aucun Ollama, aucun suivi ni compte. Permission `storage` uniquement ; accès aux pages `www.youtube.com` via content script.
- **Limitations** : heuristiques imparfaites, aucune preuve de qualité pédagogique ou de justesse mathématique ; YouTube peut changer son DOM ; les vidéos sans titre peuvent être préservées ou masquées en mode strict.
- En cas de problème, désactiver avec le bouton « Tout réafficher », ou désactiver l’extension dans `chrome://extensions/`.

## Partage
Testeurs proches : transmettre le ZIP, leur demander de le décompresser et de charger le dossier en mode développeur (uniquement pour des testeurs faisant confiance au code). Éviter les sites de téléchargement inconnus. Pour une distribution facilitée et des mises à jour automatiques, publier en visibilité **Non répertoriée** sur Chrome Web Store, soumis aux règles et revue de Google.

## Confidentialité
Aucune donnée n'est envoyée à un serveur par cette extension. Les titres des vidéos enregistrées et réglages restent dans `chrome.storage.local`. Vous pouvez effacer les favoris dans Options ou désinstaller l'extension.

## Tests
`node --test tests/*.test.cjs` (Node.js >=18). La validation dans une vraie session YouTube reste nécessaire.
